const express = require('express');
const router = express.Router();
const path = require('path');
const fs = require('fs');

router.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, '../public/employee.html'));
});

router.get('/api/data', (req, res) => {
    const employeeDataPath = path.join(__dirname, '../public/data/employees.json');
    
    fs.readFile(employeeDataPath, 'utf8', (err, data) => {
        if (err) {
            res.status(500).json({ error: 'Error reading employee data' });
            return;
        }
        res.json(JSON.parse(data));
    });
});

module.exports = router;
